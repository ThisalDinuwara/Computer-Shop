package com.digitalworld.ecommerce.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceWebApplication.class, args);
	}

}
