package com.digitalworld.ecommerce.web.domain;

public enum USER_ROLE {

    ROLE_ADMIN,
    ROLE_CUSTOMER,
    ROLE_SELLER
}
