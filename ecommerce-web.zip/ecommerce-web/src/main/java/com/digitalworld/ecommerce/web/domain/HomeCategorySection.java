package com.digitalworld.ecommerce.web.domain;

public enum HomeCategorySection {
    ELECTRIC_CATEGORIES,
    GRID,
    SHOP_BY_CATEGORIES,
    DEALS
}
