package com.digitalworld.ecommerce.web.config;

import java.security.PublicKey;

public class JWT_CONSTANT {
    public static final String SECRET_KEY = "thisissecret";
    public static final String JWT_HEADER = "Authorization";
}
