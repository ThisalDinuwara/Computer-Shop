package com.digitalworld.ecommerce.web.domain;

public enum PaymentStatus {

    PENDING,
    PROCESSING,
    COMPLETED,
    FAILED
}
