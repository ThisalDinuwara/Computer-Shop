package com.digitalworld.ecommerce.web.response;

import lombok.Data;

@Data
public class ApiResponse {
    private String message;
}
