package com.digitalworld.ecommerce.web.exceptions;

public class ProductException extends Exception{

    public ProductException(String message){
        super(message);
    }
}
