package com.digitalworld.ecommerce.web.domain;

public enum PaymentMethod {
    RAZORPAY,
    STRIPE
}
