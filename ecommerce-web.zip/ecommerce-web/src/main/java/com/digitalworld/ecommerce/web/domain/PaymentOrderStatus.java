package com.digitalworld.ecommerce.web.domain;

public enum PaymentOrderStatus {
    PENDING,
    SUCCESS,
    FAILED
}
