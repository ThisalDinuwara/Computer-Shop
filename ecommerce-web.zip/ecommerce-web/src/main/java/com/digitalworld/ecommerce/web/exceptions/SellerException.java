package com.digitalworld.ecommerce.web.exceptions;

public class SellerException extends Exception{

    public  SellerException(String message){
        super(message);
    }
}
